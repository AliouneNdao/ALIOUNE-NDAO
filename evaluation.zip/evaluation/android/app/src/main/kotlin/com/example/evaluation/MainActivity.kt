package com.example.evaluation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
