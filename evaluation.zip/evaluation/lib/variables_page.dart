void declarerVariables() {
  String nom = "alioune ndao";
  int age = 23;
  double pi = 3.14;
  bool isFlutterAwesome = true;

  final String nomComplet = "alioune ndao";
  const int vitesseLumiere = 299792458;

  print("Nom: $nom, Âge: $age, Pi: $pi, Flutter est génial: $isFlutterAwesome");
  print("Nom Complet: $nomComplet, Vitesse de la lumière: $vitesseLumiere m/s");
}
