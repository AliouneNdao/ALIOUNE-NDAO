void bonjour(String nom) {
  print("Bonjour, $nom!");
}

int addition(int a, int b) {
  return a + b;
}
